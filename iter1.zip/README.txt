3308 Blog Project

This project is a simple blog written in PHP which allows users to login, and based on their permissions allows them to post articles, create visible comments, create comments which require approval before they are made visible, or are not allowed to post comments at all. General reading of the articles and all public (visible) comments is open to the public.
