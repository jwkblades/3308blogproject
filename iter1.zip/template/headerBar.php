This is the header bar.
<span class="right">
	[[function:loginOrUserLinks:[[user:user_id]]]]
</span>
