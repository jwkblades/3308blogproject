				<ul>
					<li>
						<a href="[[url]]">
							Home
						</a>
					</li>
					<li>
						<form>
							Search by Author: 
							<input type="text" name="query" />
							<input type="submit" value="search" />
						</form>
					</li>
				</ul>
