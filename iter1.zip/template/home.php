				<div id="article">
					<h1 class="title">
						<a href="comments">
							Post Title
						</a>
					</h1>
					<p>
						This is where I wrote my blog post! Such a fascinating entry!
					</p>
					<p>
						date posted: somedate
					</p>
				</div>
				<br>
				<div id="article">
					<h1 class="title">
						<a href="comments">
							Older Post Title
						</a>
					</h1>
					<p>
						This is an older entry!
					</p>
					<p>
						date posted: somedate
					</p>
				</div>
