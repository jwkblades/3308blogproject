<form action="[[url]]?act=login" method="post">
	<input type="text" name="uname" placeholder="Username"/>
	<input type="password" name="pword" placeholder="Password"/>
	<input type="submit" name="submit" value="Login"/>
</form>
