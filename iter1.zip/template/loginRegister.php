	Login [[template:loginForm]] or
	<a href="?act=register">Register</a>
