<h1>
	Registeration Completed!
</h1>
Thank you for registering, you may not login and post comments on the blog articles.
