<h1>
	Error - Username in use
</h1>
Sorry, but the username you are attempting to use has already been registered. Please choose another and try again.
<br/>
