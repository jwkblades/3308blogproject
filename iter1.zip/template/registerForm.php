<form action="[[url]]?act=register" method="post">
	<input type="text" name="uname" placeholder="Username"/>
	<br/>
	<input type="text" name="email" placeholder="example@example.com"/>
	<br/>
	<input type="password" name="pword" placeholder="Password"/>
	<br/>
	<input type="submit" name="submit" value="Register"/>
</form>
