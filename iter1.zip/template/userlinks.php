Welcome [[user:username]] <a href="?act=logout">Logout</a>
