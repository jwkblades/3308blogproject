<?php
// config.php

$settings['mysqlUser'] = "root";
$settings['mysqlPass'] = "root";
$settings['mysqlHost'] = "localhost";
$settings['mysqlDb'] = "blog";

$config['url'] = "http://localhost/blog/";
$config['title'] = "Blogdiggity";

?>
